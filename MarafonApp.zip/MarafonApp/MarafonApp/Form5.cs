﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarafonApp
{
    public partial class Form5 : Form
    {
        Model1 db = new Model1();
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Пожалуйста, заполните все поля!");
            }    

            if (textBox2.Text != textBox3.Text)
            {
                MessageBox.Show("Введённые пароли не совпадают! Пожалуйста, проверьте пароли или введите новый");
                return;
            }

            User usr = new User();

            usr.Email = textBox1.Text;
            usr.Password = textBox2.Text;
            usr.FirstName = textBox4.Text;
            usr.LastName = textBox5.Text;
            usr.RoleId = "R";

            db.User.Add(usr);
            try
            {
                db.SaveChanges();
                MessageBox.Show("Вы успешно зарегистрировались");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }

            

            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
